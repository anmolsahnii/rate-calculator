(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=[{id:`spot`,label:`Spot`,hint:`2026 Ontario LTL, Montreal LTL and generic FTL pallet rates.`},{id:`canada`,label:`Canada Cartage`,hint:`Customer-specific Canada Cartage pallet agreement.`},{id:`ccls`,label:`CCLS / Uniqlo supplies`,hint:`CCLS supply and Quebec store-delivery pallet tables.`},{id:`efl`,label:`EFL Global`,hint:`EFL Global 2026 pallet agreement.`},{id:`ameri`,label:`Ameri-Connect`,hint:`Ameri-Connect 2026 pallet agreement.`},{id:`gobolt`,label:`GoBolt`,hint:`GoBolt contracted Montreal pallet rates with fuel included.`},{id:`muji`,label:`Muji`,hint:`Muji 2026 zone table with contracted fuel treatment included.`},{id:`nippon`,label:`Nippon Express`,hint:`Nippon pallet tariff with fuel included.`},{id:`obibox`,label:`Obibox`,hint:`Obibox GTA pallet tariff and contract FSC.`},{id:`uniqlo`,label:`Uniqlo`,hint:`Active 2026 Uniqlo store-delivery pallet tables.`},{id:`vessi`,label:`Vessi`,hint:`Vessi GTA and Vancouver 2026 pallet tables.`}],t={1:[`vaughan`,`toronto`,`scarborough`,`north york`,`mississauga`,`etobicoke`,`brampton`,`woodbridge`,`concord`],2:[`oakville`,`milton`,`georgetown`,`burlington`,`bolton`,`caledon`,`halton hills`],3:[`pickering`,`oshawa`,`orangeville`,`newmarket`,`markham`,`hamilton`,`aurora`,`richmond hill`,`whitby`],4:[`kitchener`,`guelph`,`cookstown`,`cambridge`,`barrie`,`waterloo`,`paris`],5:[`london`,`woodstock`,`peterborough`],6:[`ottawa`,`nepean`]},n={1:[`mississauga`,`etobicoke`,`brampton`,`halton hills`,`toronto premium outlets`],2:[`oakville`,`toronto`,`georgetown`,`bolton`,`vaughan`,`scarborough`,`north york`,`concord`,`woodbridge`],3:[`pickering`,`oshawa`,`orangeville`,`newmarket`,`markham`,`burlington`,`richmond hill`,`milton`,`hamilton`],4:[`kitchener`,`guelph`,`cookstown`,`cambridge`,`barrie`,`waterloo`,`paris`],5:[`london`,`niagara`,`niagara-on-the-lake`,`st catharines`],6:[`kingston`,`belleville`],7:[`ottawa`,`nepean`],8:[`montreal`,`dorval`,`lachine`,`saint-laurent`,`saint laurent`,`brossard`,`laval`],9:[`quebec`,`quebec city`,`levis`]},r=`ahuntsic.anjou.atwater.auteuil.baie-d'urfe.beaconsfield.bordeaux.boucherville.brossard.candiac.cartierville.chomedey.cote st-luc.dollard-des-ormeaux.dorval.duvernay.fabreville.greenfield park.hampstead.ile-bizard.kirkland.la prairie.lachine.lasalle.laval.longueuil.montreal.montreal-est.montreal-nord.montreal-ouest.mont-royal.outremont.pierrefonds.pointe-claire.saint-laurent.st-laurent.st-hubert.st-lambert.st-leonard.verdun.westmount.varennes.saint-eustache.ste-eustache`.split(`.`),i=[`beloeil`,`blainville`,`boisbriand`,`carignan`,`chambly`,`delson`,`iberville`,`kahnawake`,`lachenaie`,`lorraine`,`marieville`,`mascouche`,`mcmasterville`,`mirabel`,`mont-st-hilaire`,`otterburn park`,`richelieu`,`rosemere`,`st-hyacinthe`,`saint-hyacinthe`,`st-jean-sur-richelieu`,`terrebonne`,`ste-therese`,`saint-jerome`,`st-jerome`],a={uniqlo:{kitchener:[106,130,142,148,168,186,198,210,216,222,234,234],niagara:[143,210,276,342,408,474,540,606,720,750,900,400],"niagara-on-the-lake":[143,210,276,342,408,474,540,606,720,750,900,400],"st catharines":[143,210,276,342,408,474,540,606,720,750,900,400]},ccls:{ottawa:[48.1,56,84,112,130,156,182,208,234,240,264,288],montreal:[52.91,61.6,92.4,123.2,143,171.6,200.2,228.8,257.4,264,290.4,316.8],"quebec city":[63.49,74,111,148,171.5,205.8,240.1,274.4,308.7,317,348.7,380.4]},vessi:{metrotown:[492,934,1306,1748,2190,2632,3074,3516,3958,4400,4842,5284],richmond:[492,934,1306,1748,2190,2632,3074,3516,3958,4400,4842,5284],aerostream:[465,904,1286,1728,2170,2612,3054,3496,3938,4380,4822,5264]}},o={1:[`brossard`,`lasalle`,`montreal`,`repentigny`,`longueuil`,`st-bruno`,`laval`,`pointe-claire`,`mont-royal`,`st-laurent`,`terrebonne`],2:[`st-jerome`,`rosemere`,`drummondville`,`beloeil`,`st-jean`,`st-hyacinthe`,`riviere-du-loup`],3:[`quebec city`,`levis`,`gatineau`,`shawinigan`,`sherbrooke`,`joliette`,`granby`,`victoriaville`,`trois-rivieres`],4:[`chicoutimi`,`st-georges`,`rimouski`]},s=Array.from(new Set([...Object.values(t).flat(),...Object.values(n).flat(),...r,...i,...Object.values(a).flatMap(e=>Object.keys(e)),...Object.values(o).flat()])).sort((e,t)=>e.localeCompare(t)),c={canada:[`canada cartage`],ccls:[`ccls`,`uniqlo supplies`],efl:[`efl global`,`efl`],ameri:[`ameri-connect`,`ameri connect`],gobolt:[`gobolt`,`go bolt`],muji:[`muji`],nippon:[`nippon express`,`nippon`],obibox:[`obibox`],uniqlo:[`uniqlo`],vessi:[`vessi`]};function l(e){return e.toLowerCase().normalize(`NFD`).replace(/[\u0300-\u036f]/g,``).replace(/[^a-z0-9]+/g,` `).replace(/\s+/g,` `).trim()}function u(e){return e.split(/\s+/).map(e=>[`st`,`ste`].includes(e.toLowerCase())?`${e[0].toUpperCase()}${e.slice(1).toLowerCase()}.`:`${e[0]?.toUpperCase()??``}${e.slice(1).toLowerCase()}`).join(` `)}function d(e,t){let n=` ${l(e)} `,r=[...t].filter(Boolean).sort((e,t)=>t.length-e.length).find(e=>n.includes(` ${l(e)} `));return r?u(r):``}function f(e,t){let n=RegExp(`(?:${t.join(`|`)})\\s*(?:city|location|address)?\\s*(?:is\\s+|[:\\-]\\s*|\\s+)([^\\n\\r;]{2,100})`,`i`);return e.match(n)?.[1]??``}function p(e,t){let n=l(e);for(let e of t)if(e.id!==`spot`&&(c[e.id]??[e.label]).some(e=>n.includes(l(e))))return{id:e.id,detected:!0};return{id:`spot`,detected:!1}}function m(e){let t=l(e);return[`montreal`,`dorval`,`lachine`,`saint laurent`,`st laurent`].some(e=>t.includes(e))?`montreal`:t.includes(`mississauga`)?`mississauga`:null}function h(e,t){let n=`${e.subject}\n${e.body}`,r=`${e.sender}\n${n}`,i=n.match(/\b(\d{1,2})\s*(?:skids?|pallets?|plts?)\b/i)??n.match(/\b(?:skids?|pallets?|plts?)\s*[:#-]?\s*(\d{1,2})\b/i),a=i?Math.min(26,Number(i[1])):0,o=n.match(/\bfrom\s+([^\n\r;]{2,90}?)\s+\bto\s+([^\n\r;]{2,90}?)(?=[\n\r;.]|$)/i),s=f(n,[`pickup`,`pick[ -]?up`,`origin`,`collect(?:ion)?`])||o?.[1]||``,c=f(n,[`destination`,`deliver(?:y)?(?: to)?`,`ship(?:ping)? to`,`drop[ -]?off`])||o?.[2]||``,l=d(s,t.cities),u=d(c,t.cities),h=m(l),g=p(r,t.profiles),_=/\b(?:ftl|full truck(?:load)?)\b/i.test(n)?`ftl`:/\bltl\b/i.test(n)?`ltl`:`auto`,v=n.match(/\b(\d)\s*(?:helpers?|swampers?)\b/i);return{customer:g.id,customerDetected:g.detected,originType:h||!l?`warehouse`:`custom`,warehouse:h??`mississauga`,pickup:h?``:l,originDetected:!!l,destination:u,destinationDetected:!!u,pallets:a,palletsDetected:a>0,service:_,tailgate:/\b(?:tailgate|liftgate|lift gate)\b/i.test(n),inside:/\binside delivery\b/i.test(n),appointment:/\bappointment\b/i.test(n),returns:/\b(?:pallet return|return pallets?)\b/i.test(n),helpers:v?Math.min(6,Number(v[1])):0}}var g=document.querySelector(`#app`),_=`https://anmolsahnii.github.io/rate-calculator/`;function v(e){return e.replaceAll(`&`,`&amp;`).replaceAll(`<`,`&lt;`).replaceAll(`>`,`&gt;`).replaceAll(`"`,`&quot;`).replaceAll(`'`,`&#039;`)}function y(){return`
    <span class="logo" aria-hidden="true">
      <svg viewBox="0 0 48 48" focusable="false">
        <circle cx="10" cy="33" r="3.5"></circle>
        <path d="M14 33h5.5l9-12H38"></path>
        <path d="m32 15 6 6-6 6"></path>
      </svg>
    </span>
  `}function b(e){return`
    <header>
      ${y()}
      <div>
        <strong>Rate Calculator</strong>
        <span>Gmail quote reader</span>
      </div>
    </header>
    ${e}
    <footer>Built by Anmol Sahni</footer>
  `}function x(){g&&(g.innerHTML=b(`
    <section class="state">
      <span class="spinner" aria-hidden="true"></span>
      <h1>Reading open email</h1>
      <p>Looking for the customer, route, pallets, and service.</p>
    </section>
  `))}function S(e){g&&(g.innerHTML=b(`
    <section class="state error-state">
      <span class="state-icon" aria-hidden="true">!</span>
      <h1>Email not available</h1>
      <p>${v(e)}</p>
      <button id="retry" type="button">Try again</button>
    </section>
  `),document.querySelector(`#retry`)?.addEventListener(`click`,()=>void D()))}function C(e,t,n){return`<option value="${v(e)}" ${e===n?`selected`:``}>${v(t)}</option>`}function w(e){let t=document.querySelector(`#origin`)?.value;return{...e,customer:document.querySelector(`#customer`)?.value??`spot`,originType:t===`custom`?`custom`:`warehouse`,warehouse:t===`montreal`?`montreal`:`mississauga`,pickup:document.querySelector(`#pickup`)?.value.trim()??``,destination:document.querySelector(`#destination`)?.value.trim()??``,pallets:Math.min(26,Math.max(0,Number(document.querySelector(`#pallets`)?.value)||0)),service:document.querySelector(`#service`)?.value??`auto`}}async function T(e){let t=new URL(_);t.searchParams.set(`customer`,e.customer),t.searchParams.set(`destination`,e.destination),t.searchParams.set(`pallets`,String(e.pallets)),t.searchParams.set(`service`,e.service),t.searchParams.set(`market`,`10`),t.searchParams.set(`source`,`gmail`),e.originType===`custom`&&e.pickup?t.searchParams.set(`pickup`,e.pickup):t.searchParams.set(`warehouse`,e.warehouse),e.tailgate&&t.searchParams.set(`tailgate`,`1`),e.inside&&t.searchParams.set(`inside`,`1`),e.appointment&&t.searchParams.set(`appointment`,`1`),e.returns&&t.searchParams.set(`returns`,`1`),e.helpers&&t.searchParams.set(`helpers`,String(e.helpers)),await chrome.tabs.create({url:t.toString()}),window.close()}function E(t,n,r=!0){if(!g)return;let i=!t.originDetected||!t.destinationDetected||!t.palletsDetected,a=t.originType===`custom`?`custom`:t.warehouse;g.innerHTML=b(`
    <section class="summary">
      <div>
        <span class="eyebrow">Email analyzed</span>
        <h1>${i?`Review shipment details`:`Quote details found`}</h1>
      </div>
      <span class="status ${i?`review`:`ready`}">
        ${i?`Review`:`Ready`}
      </span>
    </section>
    <p class="subject" title="${v(n.subject)}">${v(n.subject)}</p>
    <form id="quote-form">
      <label>
        <span>Customer</span>
        <select id="customer">
          ${e.map(e=>C(e.id,e.label,t.customer)).join(``)}
        </select>
      </label>
      <label>
        <span>Pickup origin</span>
        <select id="origin" class="${t.originDetected?``:`needs-review`}">
          ${C(`mississauga`,`Mississauga warehouse`,a)}
          ${C(`montreal`,`Montreal warehouse`,a)}
          ${C(`custom`,`Other pickup`,a)}
        </select>
        ${t.originDetected?``:`<small>Not stated in the email. Mississauga is selected.</small>`}
      </label>
      <label id="pickup-field" class="${t.originType===`custom`?``:`hidden`}">
        <span>Pickup city</span>
        <input id="pickup" value="${v(t.pickup)}" placeholder="City, province" />
      </label>
      <div class="field-row">
        <label>
          <span>Destination</span>
          <input
            id="destination"
            class="${t.destinationDetected?``:`needs-review`}"
            value="${v(t.destination)}"
            placeholder="City, province"
          />
        </label>
        <label>
          <span>Pallets</span>
          <input
            id="pallets"
            class="${t.palletsDetected?``:`needs-review`}"
            type="number"
            min="1"
            max="26"
            value="${t.pallets||``}"
            placeholder="0"
          />
        </label>
      </div>
      <label>
        <span>Service</span>
        <select id="service">
          ${C(`auto`,`Auto`,t.service)}
          ${C(`ltl`,`LTL`,t.service)}
          ${C(`ftl`,`FTL`,t.service)}
        </select>
      </label>
      <button class="primary" type="submit">Open calculated quote</button>
      <p id="form-error" class="form-error" role="alert"></p>
    </form>
  `);let o=document.querySelector(`#origin`),s=document.querySelector(`#pickup-field`);o?.addEventListener(`change`,()=>{s?.classList.toggle(`hidden`,o.value!==`custom`)}),document.querySelector(`#quote-form`)?.addEventListener(`submit`,e=>{e.preventDefault();let n=w(t),r=document.querySelector(`#form-error`);if(!n.destination||n.pallets<1){r&&(r.textContent=`Destination and pallet count are required.`);return}if(n.originType===`custom`&&!n.pickup){r&&(r.textContent=`Pickup city is required.`);return}T(n)}),!i&&r&&window.setTimeout(()=>void T(t),700)}async function D(){x();try{let[t]=await chrome.tabs.query({active:!0,currentWindow:!0});if(!t?.id||t.url!==void 0&&!t.url.startsWith(`https://mail.google.com/`)){S(`Open the customer quote email in Gmail and try again.`);return}let n=await chrome.tabs.sendMessage(t.id,{type:`analyze-rate-email`});if(`error`in n){S(n.error);return}E(h(n,{cities:s,profiles:e}),n)}catch{S(`Refresh the Gmail tab once after installing the extension, then try again.`)}}if(window.location.protocol!==`chrome-extension:`&&new URLSearchParams(window.location.search).get(`preview`)===`1`){let t={subject:`Quote request · Mississauga to Brampton`,sender:`Vessi Operations <ops@example.com>`,body:`Please quote 4 pallets from Mississauga, ON to Brampton, ON. LTL service.`,url:window.location.href};E(h(t,{cities:s,profiles:e}),t,!1)}else D();